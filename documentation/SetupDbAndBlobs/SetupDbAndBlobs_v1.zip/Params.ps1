﻿Set-StrictMode -Version Latest
Set-ExecutionPolicy -Scope CurrentUser Unrestricted

$clientKey = "bdEdr99NFpzy4Xt12KEO2zyfhDMx7HgYqXf1JAQVLfL72NMO"
$clientSecret = "EEn9rhQ1ZcIj1KVyIJ9kin04WNoeU6HXholCM1YcXDPZ37Wu5xDbGUXhvArr8HKI"
$projectId = "f0286c0b-994e-45a8-9cd8-d11f6753b52b"
$environment = "Integration"
